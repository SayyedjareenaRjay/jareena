package com.example.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.model.Exam;
import com.example.repository.ExamRepository;

@Service
public class ExamService {
	 @Autowired
	    private ExamRepository examRepository;

	    public void submitExam(Exam exam) {
	        examRepository.save(exam);
	    }

}
