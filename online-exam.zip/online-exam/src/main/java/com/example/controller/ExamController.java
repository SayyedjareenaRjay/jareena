package com.example.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.model.Exam;
import com.example.service.ExamService;

@RestController
@RequestMapping("/api/exams")
@CrossOrigin(origins = "*")
public class ExamController {

    @Autowired
    private ExamService examService;


    @PostMapping("/submit")
    public ResponseEntity<Map<String, String>> submitExam(@RequestBody Exam exam) {
        examService.submitExam(exam);
        Map<String, String> response = new HashMap<>();
        response.put("message", "Exam submitted successfully");
        return ResponseEntity.ok(response); // Return JSON response
    }
}
