let examData = {}; // Store your exam data here

// Function to submit the exam
function submitExam() {
    // Capture the textarea value
    examData.answers = document.getElementById('exam-input').value;

    fetch('/api/exams/submit', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(examData), // Pass the exam data
    })
    .then(response => {
        if (response.ok) {
            alert("Exam submitted successfully!");
            // Optionally, redirect to another page or show a success message
        } else {
            alert("Failed to submit the exam.");
        }
    })
    .catch(error => {
        console.error('Error:', error);
    });
}

// Detect tab switching
window.addEventListener('visibilitychange', function() {
    if (document.visibilityState === 'hidden') {
        // The tab is hidden; submit the exam
        submitExam();
    }
});
